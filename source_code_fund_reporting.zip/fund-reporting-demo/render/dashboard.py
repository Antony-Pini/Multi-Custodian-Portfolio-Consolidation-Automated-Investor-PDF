"""Operations dashboard (dark), rendered to HTML then screenshotted."""
from html import escape
from pathlib import Path

import pandas as pd

from .charts import (CLASS_ORDER, DARK, pct, signed, allocation_strip, class_colors, contribution_bars,
                     monthly_bars, performance_chart)

FONT = (Path(__file__).resolve().parents[1] / "assets" / "InterVariable.ttf").as_uri()


def eur(x, d=1):
    return f"€{x / 1e6:,.{d}f}M"


def base_css(t):
    return f"""
@font-face {{ font-family: Inter; src: url('{FONT}'); font-weight: 100 900; }}
* {{ box-sizing: border-box; margin: 0; padding: 0; }}
html, body {{ background: {t['page']}; color: {t['ink']}; font-family: Inter, sans-serif;
  -webkit-font-smoothing: antialiased; font-feature-settings: 'cv11', 'ss01'; }}
.card {{ background: {t['surface']}; border: 1px solid {t['border']}; border-radius: 14px; padding: 22px 24px; }}
.eyebrow {{ font-size: 12px; letter-spacing: .08em; text-transform: uppercase; color: {t['muted']}; font-weight: 600; }}
.h {{ font-size: 16px; font-weight: 600; color: {t['ink']}; }}
.sub {{ font-size: 13px; color: {t['ink2']}; }}
.num {{ font-variant-numeric: tabular-nums; }}
.chip {{ display: inline-flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 600; padding: 3px 9px;
  border-radius: 999px; border: 1px solid {t['border']}; color: {t['ink']}; white-space: nowrap; }}
.dot {{ width: 8px; height: 8px; border-radius: 50%; display: inline-block; }}
.legend {{ display: flex; gap: 18px; font-size: 13px; color: {t['ink2']}; align-items: center; }}
.sw {{ width: 12px; height: 3px; border-radius: 2px; display: inline-block; margin-right: 6px; vertical-align: middle; }}
.sq {{ width: 10px; height: 10px; border-radius: 3px; display: inline-block; margin-right: 6px; vertical-align: -1px; }}
"""


STATUS_ICON = {"Pass": "✓", "Auto-fixed": "↻", "Warning": "▲", "Break": "✕"}


def status_color(t, s):
    return {"Pass": t["good"], "Auto-fixed": t["good"], "Warning": t["warn"], "Break": t["crit"]}[s]


def status_chip(t, s):
    c = status_color(t, s)
    return f'<span class="chip"><span style="color:{c}">{STATUS_ICON[s]}</span>{s}</span>'


def build(r: dict) -> str:
    t = DARK
    fs, bs = r["fund_stats"], r["bench_stats"]
    hist, pos = r["history"], r["positions"]
    nav = hist["nav"].iloc[-1]
    sep = r["monthly"]["fund"].iloc[-1]
    sep_b = r["monthly"]["benchmark"].iloc[-1]
    alloc_w = pos.groupby("asset_class")["weight"].sum()
    alloc_v = pos.groupby("asset_class")["market_value_eur"].sum()
    cc = class_colors(t)
    cs = r["check_summary"]

    kpis = [
        ("Net asset value", eur(nav, 2), f"{r['n_positions']} positions · 3 custodians"),
        ("YTD return (TWR)", pct(fs['ytd']), f"Benchmark {pct(bs['ytd'])} · <span style='color:{t['good_text']}'>▲ {signed((fs['ytd'] - bs['ytd']) * 1e4, 0)} bp</span>"),
        ("September", pct(sep), f"Benchmark {pct(sep_b)}"),
        ("Volatility (ann.)", f"{fs['vol']:.1%}", f"Sharpe {fs['sharpe']:.2f}"),
        ("Max drawdown", pct(fs['max_dd']), f"Trough {fs['max_dd_date']:%d %b}"),
    ]
    kpi_html = "".join(
        f'<div class="card kpi"><div class="eyebrow">{k}</div><div class="kv num">{v}</div><div class="sub">{s}</div></div>'
        for k, v, s in kpis)

    alloc_rows = "".join(
        f'<div class="arow"><span><span class="sq" style="background:{cc[k]}"></span>{k}</span>'
        f'<span class="num sub">{eur(alloc_v.get(k, 0))}</span><span class="num aw">{alloc_w.get(k, 0):.1%}</span></div>'
        for k in CLASS_ORDER)

    issues = r["checks"][r["checks"]["status"] != "Pass"]
    issue_html = "".join(
        f'<div class="issue">{status_chip(t, row.status)}<div><div class="it">{escape(row.check)}</div>'
        f'<div class="sub">{escape(row.detail)}</div></div></div>' for row in issues.itertuples())
    tally = "".join(
        f'<div class="tally"><span class="tn num">{cs[s]}</span><span class="sub"><span style="color:{status_color(t, s)}">{STATUS_ICON[s]}</span> {s}</span></div>'
        for s in ["Pass", "Auto-fixed", "Warning", "Break"])

    cm = r["contrib_month"]
    movers = pd.concat([cm.sort_values(ascending=False).head(4), cm.sort_values().head(3).sort_values(ascending=False)])

    sources = [
        ("US broker", "CSV export", "USD · ISO dates", "7 lines"),
        ("Private bank", "Excel statement", "EUR · French format", "7 lines"),
        ("Crypto exchange", "JSON API", "USD · epoch ms", "4 balances"),
    ]
    src_html = "".join(
        f'<div class="src"><div><div class="it">{a}</div><div class="sub">{b} · {c}</div></div><span class="chip"><span style="color:{t["good"]}">✓</span>Ingested</span></div>'
        for a, b, c, d in sources)

    return f"""<!doctype html><html><head><meta charset="utf-8"><style>{base_css(t)}
body {{ width: 1600px; height: 1200px; padding: 36px 40px; }}
.top {{ display:flex; justify-content:space-between; align-items:flex-end; margin-bottom: 22px; }}
.brand {{ display:flex; align-items:center; gap:14px; }}
.logo {{ width:40px; height:40px; border-radius:10px; background:{t['s1']}; display:grid; place-items:center; font-weight:700; font-size:18px; }}
.title {{ font-size: 24px; font-weight: 650; letter-spacing: -.01em; }}
.meta {{ display:flex; gap:8px; }}
.kpis {{ display:grid; grid-template-columns: repeat(5, 1fr); gap: 16px; margin-bottom: 16px; }}
.kpi {{ padding: 18px 22px; }}
.kv {{ font-size: 32px; font-weight: 650; letter-spacing: -.02em; margin: 8px 0 4px; }}
.grid {{ display:grid; grid-template-columns: 1fr 420px; gap: 16px; }}
.ch {{ display:flex; justify-content:space-between; align-items:center; margin-bottom: 14px; }}
.arow {{ display:grid; grid-template-columns: 1fr auto 64px; gap: 10px; font-size: 14px; padding: 9px 0; border-top: 1px solid {t['grid']}; }}
.aw {{ text-align:right; font-weight:600; }}
.tallies {{ display:grid; grid-template-columns: repeat(4,1fr); gap: 8px; margin: 4px 0 12px; }}
.tally {{ background:{t['page']}; border-radius:10px; padding:9px 10px; white-space:nowrap; display:flex; flex-direction:column; gap:2px; }}
.tally .sub {{ font-size: 12px; }}
.tn {{ font-size: 22px; font-weight: 650; }}
.issue {{ display:grid; grid-template-columns: 108px 1fr; gap:10px; padding: 8px 0; border-top: 1px solid {t['grid']}; align-items:start; }}
.issue .sub {{ font-size: 12px; line-height: 1.4; }}
.it {{ font-size: 13.5px; font-weight: 600; margin-bottom: 2px; }}
.bottom {{ display:grid; grid-template-columns: 1fr 1fr 420px; gap: 16px; margin-top: 16px; }}
.src {{ display:flex; justify-content:space-between; align-items:center; padding: 11px 0; border-top: 1px solid {t['grid']}; }}
.demo {{ color:{t['muted']}; font-size: 12px; }}
</style></head><body>
<div class="top">
  <div class="brand"><div class="logo">A</div><div><div class="title">Aurelia Capital — Consolidated Portfolio</div>
  <div class="sub">Operations dashboard · generated automatically from 3 custodian files · <span class="demo">fictional demo data</span></div></div></div>
  <div class="meta"><span class="chip">As of 30 Sep 2026</span><span class="chip">Base currency EUR</span>
  <span class="chip">EUR/USD {r['eurusd']:.4f}</span><span class="chip"><span style="color:{t['good']}">●</span>Pipeline run {r['runtime_s']:.2f}s</span></div>
</div>
<div class="kpis">{kpi_html}</div>
<div class="grid">
  <div class="card">
    <div class="ch"><div><div class="h">Cumulative return, year to date</div><div class="sub">Time-weighted, net of capital flows · indexed to 31 Dec 2025</div></div>
    <div class="legend"><span><span class="sw" style="background:{t['s1']}"></span>Fund</span><span><span class="sw" style="background:{t['bench']}"></span>60/40 benchmark</span></div></div>
    {performance_chart(hist, r['flows'], t, w=1000, h=356)}
  </div>
  <div class="card">
    <div class="ch"><div class="h">Asset allocation</div><div class="sub num">{eur(nav, 2)}</div></div>
    {allocation_strip(alloc_w, t, w=370)}
    <div style="margin-top:14px">{alloc_rows}</div>
    <div class="ch" style="margin:22px 0 4px"><div class="h">Sources</div><div class="sub">30 Sep 2026</div></div>
    {src_html}
  </div>
</div>
<div class="bottom">
  <div class="card">
    <div class="ch"><div class="h">Monthly returns</div><div class="legend"><span><span class="sq" style="background:{t['s1']}"></span>Fund</span><span><span class="sq" style="background:{t['bench']}"></span>Benchmark</span></div></div>
    {monthly_bars(r['monthly'], t, w=520, h=270)}
  </div>
  <div class="card">
    <div class="ch"><div class="h">September contributors</div><div class="sub">bp of NAV</div></div>
    {contribution_bars(movers, t, w=520, row=33, label_w=180)}
  </div>
  <div class="card">
    <div class="ch"><div class="h">Data quality</div><div class="sub">{cs['total']} automated checks</div></div>
    <div class="tallies">{tally}</div>
    {issue_html}
  </div>
</div>
</body></html>"""
