"""Investor report (light, A4), printed to PDF by headless Chromium."""
from html import escape

import pandas as pd

from .charts import (CLASS_ORDER, LIGHT, allocation_strip, class_colors, contribution_bars,
                     monthly_bars, pct, performance_chart, signed)
from .dashboard import FONT, eur


def commentary(r) -> str:
    """Manager commentary drafted from the numbers (a human reviews it before sending)."""
    m, b = r["monthly"]["fund"].iloc[-1], r["monthly"]["benchmark"].iloc[-1]
    fs, bs = r["fund_stats"], r["bench_stats"]
    c = r["contrib_month"].sort_values()
    top = c.tail(2)[::-1]
    worst = c.head(1)
    cls = r["contrib_ytd_by_class"].sort_values(ascending=False)
    return (
        f"The fund returned <b>{pct(m)}</b> in September, against {pct(b)} for its 60/40 benchmark, "
        f"bringing the year-to-date time-weighted return to <b>{pct(fs['ytd'])}</b> "
        f"({signed((fs['ytd'] - bs['ytd']) * 1e4, 0)} bp ahead of the benchmark). "
        f"The largest contributors were {top.index[0]} ({signed(top.iloc[0] * 1e4, 0)} bp) and "
        f"{top.index[1]} ({signed(top.iloc[1] * 1e4, 0)} bp); {worst.index[0]} was the main detractor "
        f"({signed(worst.iloc[0] * 1e4, 0)} bp). Since January, {cls.index[0].lower()} has driven most of the "
        f"performance ({signed(cls.iloc[0] * 1e4, 0)} bp). Net asset value stands at <b>{eur(r['history']['nav'].iloc[-1], 2)}</b> "
        f"after a €1.0M subscription in April and a €0.4M redemption in July.")


def build(r: dict) -> str:
    t = LIGHT
    hist, pos, fs, bs = r["history"], r["positions"], r["fund_stats"], r["bench_stats"]
    nav = hist["nav"].iloc[-1]
    mo = r["monthly"]
    cc = class_colors(t)
    alloc_w = pos.groupby("asset_class")["weight"].sum()
    alloc_v = pos.groupby("asset_class")["market_value_eur"].sum()
    n_pages = 4

    def page(n, body):
        return f"""<section class="page">
  <header><div class="brand"><span class="logo">A</span>Aurelia Capital</div>
  <div class="hr">Monthly investor report · September 2026</div></header>
  {body}
  <footer><span>Fictional demonstration data — generated automatically by the reporting pipeline. Not investment advice.</span><span>{n} / {n_pages}</span></footer>
</section>"""

    kpis = [("Net asset value", eur(nav, 2), "30 Sep 2026"),
            ("September", pct(mo['fund'].iloc[-1]), f"Benchmark {pct(mo['benchmark'].iloc[-1])}"),
            ("Year to date", pct(fs['ytd']), f"Benchmark {pct(bs['ytd'])}"),
            ("Excess return YTD", f"{signed((fs['ytd'] - bs['ytd']) * 1e4, 0)} bp", "Fund vs benchmark")]
    kpi_html = "".join(f'<div class="kpi"><div class="eyebrow">{a}</div><div class="kv">{b}</div><div class="sub">{c}</div></div>' for a, b, c in kpis)

    top5 = "".join(f"<tr><td>{escape(x.name)}</td><td><span class='sq' style='background:{cc[x.asset_class]}'></span>{x.asset_class}</td>"
                   f"<td>{x.source}</td><td class='r'>{x.market_value_eur:,.0f}</td><td class='r'>{x.weight:.1%}</td></tr>"
                   for x in pos.head(5).itertuples())
    p1 = page(1, f"""
  <div class="hero"><div class="eyebrow">Monthly report</div><h1>September 2026</h1>
  <p class="lead">Consolidated view of the portfolio held across a US broker, a French private bank and a crypto exchange, valued in euros.</p></div>
  <div class="kpis">{kpi_html}</div>
  <h2>Performance</h2>
  <div class="legend"><span><span class="sw" style="background:{t['s1']}"></span>Fund</span><span><span class="sw" style="background:{t['bench']}"></span>60/40 benchmark</span><span class="muted">Cumulative, time-weighted, net of capital flows</span></div>
  {performance_chart(hist, r['flows'], t, w=720, h=285, font=11)}
  <h2>Manager commentary</h2>
  <p class="body">{commentary(r)}</p>
  <h2>Five largest positions</h2>
  <table class="dense"><thead><tr><th>Instrument</th><th>Asset class</th><th>Custodian</th><th class='r'>Value (EUR)</th><th class='r'>Weight</th></tr></thead>
  <tbody>{top5}</tbody></table>
""")

    alloc_rows = "".join(
        f"<tr><td><span class='sq' style='background:{cc[k]}'></span>{k}</td><td class='r'>{alloc_v.get(k, 0):,.0f}</td>"
        f"<td class='r'>{alloc_w.get(k, 0):.1%}</td><td class='r'>{signed(r['contrib_ytd_by_class'].get(k, 0) * 1e4, 0)} bp</td></tr>"
        for k in CLASS_ORDER)
    mrows = "".join(
        f"<tr><td>{d:%B}</td><td class='r'>{pct(row.fund)}</td><td class='r'>{pct(row.benchmark)}</td>"
        f"<td class='r'>{signed((row.fund - row.benchmark) * 1e4, 0)} bp</td></tr>" for d, row in mo.iterrows())
    risk = [("Return, year to date", pct(fs['ytd']), pct(bs['ytd'])),
            ("Return, annualised", pct(fs['ann_return']), pct(bs['ann_return'])),
            ("Volatility, annualised", f"{fs['vol']:.1%}", f"{bs['vol']:.1%}"),
            ("Sharpe ratio (rf 2.0%)", f"{fs['sharpe']:.2f}", f"{bs['sharpe']:.2f}"),
            ("Maximum drawdown", pct(fs['max_dd']), pct(bs['max_dd']))]
    rrows = "".join(f"<tr><td>{a}</td><td class='r'>{b}</td><td class='r'>{c}</td></tr>" for a, b, c in risk)

    p2 = page(2, f"""
  <h2 class="first">Asset allocation</h2>
  {allocation_strip(alloc_w, t, w=720, h=16)}
  <table><thead><tr><th>Asset class</th><th class='r'>Market value (EUR)</th><th class='r'>Weight</th><th class='r'>YTD contribution</th></tr></thead>
  <tbody>{alloc_rows}</tbody><tfoot><tr><td>Total</td><td class='r'>{nav:,.0f}</td><td class='r'>100.0%</td><td class='r'>{signed(r['contrib_ytd_by_class'].sum() * 1e4, 0)} bp</td></tr></tfoot></table>
  <div class="two">
    <div><h2>Monthly returns</h2>
      <table><thead><tr><th>Month</th><th class='r'>Fund</th><th class='r'>Bench.</th><th class='r'>Excess</th></tr></thead><tbody>{mrows}</tbody></table></div>
    <div><h2>Risk and return</h2>
      <table><thead><tr><th></th><th class='r'>Fund</th><th class='r'>Bench.</th></tr></thead><tbody>{rrows}</tbody></table>
      <div class="legend" style="margin-top:18px"><span><span class="sq" style="background:{t['s1']}"></span>Fund</span><span><span class="sq" style="background:{t['bench']}"></span>Benchmark</span></div>
      {monthly_bars(mo, t, w=340, h=235, font=10)}</div>
  </div>
""")

    hold = pos.copy()
    rows = []
    for k in CLASS_ORDER:
        sub = hold[hold["asset_class"] == k]
        rows.append(f"<tr class='grp'><td colspan='6'><span class='sq' style='background:{cc[k]}'></span>{k}</td>"
                    f"<td class='r'>{sub['market_value_eur'].sum():,.0f}</td><td class='r'>{sub['weight'].sum():.1%}</td></tr>")
        for x in sub.itertuples():
            px = "" if x.instrument.endswith("_CASH") else f"{x.price:,.2f}"
            qty = f"{x.quantity:,.2f}" if x.quantity % 1 else f"{x.quantity:,.0f}"
            rows.append(f"<tr><td>{escape(x.name)}</td><td>{x.source}</td><td class='r'>{qty}</td><td class='r'>{px}</td>"
                        f"<td>{x.currency}</td><td class='r'>{x.fx_to_eur:.4f}</td><td class='r'>{x.market_value_eur:,.0f}</td><td class='r'>{x.weight:.1%}</td></tr>")
    p3 = page(3, f"""
  <h2 class="first">Holdings at 30 September 2026</h2>
  <table class="dense"><thead><tr><th>Instrument</th><th>Custodian</th><th class='r'>Quantity</th><th class='r'>Price</th><th>Ccy</th><th class='r'>FX to EUR</th><th class='r'>Value (EUR)</th><th class='r'>Weight</th></tr></thead>
  <tbody>{''.join(rows)}</tbody><tfoot><tr><td colspan='6'>Total net asset value</td><td class='r'>{nav:,.0f}</td><td class='r'>100.0%</td></tr></tfoot></table>
  <p class="note">Bonds are quoted in percent of nominal (quantity in units of €100 nominal). USD assets converted at EUR/USD {r['eurusd']:.4f}, vendor fixing of 30 Sep 2026.</p>
""")

    cm = r["contrib_month"].sort_values(ascending=False)
    movers = pd.concat([cm.head(5), cm.tail(5)])
    flows = "".join(f"<tr><td>{d:%d %b %Y}</td><td>{'Subscription' if a > 0 else 'Redemption'}</td><td class='r'>{signed(a, 0)}</td></tr>" for d, a in r["flows"].items())
    cs = r["check_summary"]
    p4 = page(4, f"""
  <h2 class="first">September contributors</h2>
  <p class="muted" style="margin-bottom:10px">Five largest positive and negative contributions, in basis points of net asset value</p>
  {contribution_bars(movers, t, w=720, row=27, font=11, label_w=230)}
  <div class="two">
    <div><h2>Capital flows, 2026</h2>
      <table><thead><tr><th>Date</th><th>Type</th><th class='r'>Amount (EUR)</th></tr></thead><tbody>{flows}</tbody></table></div>
    <div><h2>Data controls this month</h2>
      <table><tbody><tr><td>Automated checks run</td><td class='r'>{cs['total']}</td></tr>
      <tr><td>Passed</td><td class='r'>{cs['Pass']}</td></tr><tr><td>Corrected automatically</td><td class='r'>{cs['Auto-fixed']}</td></tr>
      <tr><td>Reviewed by operations</td><td class='r'>{cs['Warning'] + cs['Break']}</td></tr></tbody></table></div>
  </div>
  <h2>Methodology</h2>
  <ul class="method">
    <li><b>Sources.</b> Positions are taken from the three custodian statements (CSV, Excel and JSON), normalised to one schema and reconciled against the fund's own ledger.</li>
    <li><b>Valuation.</b> Custodian prices are cross-checked against an independent vendor close; stale prices are replaced by the vendor close of the reporting date.</li>
    <li><b>Currency.</b> The base currency is the euro; USD assets are converted at the daily vendor EUR/USD fixing.</li>
    <li><b>Performance.</b> Returns are time-weighted and neutralise subscriptions and redemptions. The benchmark is a daily rebalanced 60% global equity / 40% euro bond composite.</li>
    <li><b>Risk.</b> Volatility is the annualised standard deviation of daily returns; the Sharpe ratio uses a 2.0% risk-free rate.</li>
  </ul>
""")

    return f"""<!doctype html><html><head><meta charset="utf-8"><style>
@font-face {{ font-family: Inter; src: url('{FONT}'); font-weight: 100 900; }}
@page {{ size: A4; margin: 0; }}
* {{ box-sizing: border-box; margin: 0; padding: 0; }}
body {{ font-family: Inter, sans-serif; color: {t['ink']}; -webkit-font-smoothing: antialiased; font-size: 10.5pt; }}
.page {{ width: 210mm; height: 297mm; padding: 16mm 17mm 14mm; position: relative; page-break-after: always; background: #fff; overflow: hidden; }}
header {{ display:flex; justify-content:space-between; align-items:center; padding-bottom: 10px; border-bottom: 1px solid {t['grid']}; margin-bottom: 22px; font-size: 9pt; color: {t['ink2']}; }}
.brand {{ display:flex; align-items:center; gap:8px; font-weight:650; color:{t['ink']}; font-size: 10.5pt; }}
.logo {{ width:20px; height:20px; border-radius:5px; background:{t['s1']}; color:#fff; display:grid; place-items:center; font-size:11px; font-weight:700; }}
footer {{ position:absolute; left:17mm; right:17mm; bottom:9mm; display:flex; justify-content:space-between; font-size: 7.5pt; color:{t['muted']}; border-top: 1px solid {t['grid']}; padding-top: 7px; }}
.eyebrow {{ font-size: 7.5pt; letter-spacing: .08em; text-transform: uppercase; color: {t['muted']}; font-weight: 600; }}
h1 {{ font-size: 30pt; font-weight: 650; letter-spacing: -.02em; margin: 4px 0 8px; }}
h2 {{ font-size: 12pt; font-weight: 650; margin: 22px 0 10px; }}
h2.first {{ margin-top: 0; }}
.lead {{ font-size: 11pt; color: {t['ink2']}; max-width: 150mm; line-height: 1.5; }}
.kpis {{ display:grid; grid-template-columns: repeat(4,1fr); gap: 10px; margin: 20px 0 6px; }}
.kpi {{ border: 1px solid {t['grid']}; border-radius: 8px; padding: 11px 13px; }}
.kv {{ font-size: 17pt; font-weight: 650; letter-spacing: -.01em; margin: 5px 0 2px; }}
.sub, .muted {{ color: {t['ink2']}; font-size: 8.5pt; }}
.legend {{ display:flex; gap:14px; font-size: 8.5pt; color: {t['ink2']}; margin-bottom: 6px; align-items:center; }}
.sw {{ width: 12px; height: 3px; border-radius: 2px; display:inline-block; margin-right:5px; vertical-align: middle; }}
.sq {{ width: 9px; height: 9px; border-radius: 2px; display:inline-block; margin-right:7px; vertical-align: -0.5px; }}
.body {{ line-height: 1.6; color: {t['ink']}; font-size: 10pt; }}
table {{ width: 100%; border-collapse: collapse; font-variant-numeric: tabular-nums; margin-top: 10px; font-size: 9.5pt; }}
th {{ text-align:left; font-size: 7.5pt; text-transform: uppercase; letter-spacing: .06em; color: {t['muted']}; font-weight: 600; padding: 6px 6px; border-bottom: 1px solid {t['axis']}; }}
td {{ padding: 6.5px 6px; border-bottom: 1px solid {t['grid']}; }}
.r {{ text-align: right; }}
tfoot td {{ font-weight: 650; border-bottom: none; border-top: 1px solid {t['axis']}; }}
.dense td {{ padding: 5px 5px; font-size: 8.5pt; }}
.dense th {{ padding: 5px 5px; }}
tr.grp td {{ font-weight: 650; background: {t['page']}; }}
.two {{ display:grid; grid-template-columns: 1fr 1fr; gap: 24px; }}
.note {{ font-size: 8pt; color: {t['ink2']}; margin-top: 10px; line-height: 1.5; }}
.method {{ list-style: none; font-size: 9pt; line-height: 1.55; color: {t['ink']}; }}
.method li {{ margin-bottom: 7px; }}
</style></head><body>{p1}{p2}{p3}{p4}</body></html>"""
