"""Hand-built SVG charts (no charting library): full control over the look,
identical output in the HTML dashboard and the PDF report."""
from html import escape

import numpy as np
import pandas as pd

DARK = dict(page="#0d0d0d", surface="#1a1a19", ink="#ffffff", ink2="#c3c2b7", muted="#898781",
            grid="#2c2c2a", axis="#383835", border="rgba(255,255,255,0.10)",
            s1="#3987e5", s2="#d95926", s3="#199e70", s4="#c98500", neg="#e66767", bench="#898781",
            good="#0ca30c", warn="#fab219", crit="#d03b3b", good_text="#0ca30c")
LIGHT = dict(page="#f9f9f7", surface="#fcfcfb", ink="#0b0b0b", ink2="#52514e", muted="#898781",
             grid="#e1e0d9", axis="#c3c2b7", border="rgba(11,11,11,0.10)",
             s1="#2a78d6", s2="#eb6834", s3="#1baf7a", s4="#eda100", neg="#e34948", bench="#898781",
             good="#0ca30c", warn="#fab219", crit="#d03b3b", good_text="#006300")

CLASS_ORDER = ["Equity", "Fixed Income", "Crypto", "Cash & MMF"]


def signed(v, d=1):
    """Signed number with a true minus sign."""
    return f"{v:+,.{d}f}".replace("-", "−")


def pct(v, d=1):
    if abs(v) < 1e-12:
        return "0%"
    return f"{v:+.{d}%}".replace("-", "−")


def class_colors(t):
    return dict(zip(CLASS_ORDER, [t["s1"], t["s2"], t["s3"], t["s4"]]))


def _nice_ticks(lo, hi, n=5):
    span = hi - lo
    raw = span / n
    mag = 10 ** np.floor(np.log10(raw))
    step = min([1, 2, 5, 10], key=lambda s: abs(s * mag - raw)) * mag
    start = np.floor(lo / step) * step
    ticks = np.arange(start, hi + step * 0.5, step)
    return ticks, step


def _bar_path(x, y0, w, y1, r=4):
    """Bar anchored on the baseline y0, rounded only at the data end y1."""
    h = y1 - y0
    r = min(r, abs(h), w / 2)
    if abs(h) < 0.5:
        return ""
    if h < 0:  # grows upward
        return (f"M{x},{y0} V{y1 + r} Q{x},{y1} {x + r},{y1} H{x + w - r} "
                f"Q{x + w},{y1} {x + w},{y1 + r} V{y0} Z")
    return (f"M{x},{y0} V{y1 - r} Q{x},{y1} {x + r},{y1} H{x + w - r} "
            f"Q{x + w},{y1} {x + w},{y1 - r} V{y0} Z")


def performance_chart(hist: pd.DataFrame, flows: pd.Series, t, w=920, h=360, font=13):
    """Cumulative return of fund vs benchmark, both indexed to the same base (one axis)."""
    pad_l, pad_r, pad_t, pad_b = 56, 150, 16, 34
    f = hist["index"] / 100 - 1
    b = hist["benchmark"] / 100 - 1
    lo, hi = min(f.min(), b.min()), max(f.max(), b.max())
    ticks, step = _nice_ticks(lo - 0.005, hi + 0.005, 5)
    y_lo, y_hi = ticks[0], ticks[-1]
    iw, ih = w - pad_l - pad_r, h - pad_t - pad_b
    x0 = hist.index[0]
    span = (hist.index[-1] - x0).days

    def X(d):
        return pad_l + (d - x0).days / span * iw

    def Y(v):
        return pad_t + (y_hi - v) / (y_hi - y_lo) * ih

    out = [f'<svg viewBox="0 0 {w} {h}" width="100%" xmlns="http://www.w3.org/2000/svg" '
           f'font-family="Inter, sans-serif" font-size="{font}">']
    for v in ticks:
        y = Y(v)
        col = t["axis"] if abs(v) < 1e-12 else t["grid"]
        out.append(f'<line x1="{pad_l}" x2="{w - pad_r}" y1="{y:.1f}" y2="{y:.1f}" stroke="{col}" stroke-width="1"/>')
        out.append(f'<text x="{pad_l - 10}" y="{y + 4:.1f}" text-anchor="end" fill="{t["muted"]}" '
                   f'style="font-variant-numeric:tabular-nums">{pct(v, 0)}</text>')
    for m in pd.date_range(x0, hist.index[-1], freq="MS"):
        out.append(f'<text x="{X(m):.1f}" y="{h - 10}" text-anchor="middle" fill="{t["muted"]}">{m:%b}</text>')

    def path(s):
        return "M" + " L".join(f"{X(d):.1f},{Y(v):.1f}" for d, v in s.items())

    out.append(f'<path d="{path(b)}" fill="none" stroke="{t["bench"]}" stroke-width="2" stroke-linejoin="round"/>')
    out.append(f'<path d="{path(f)}" fill="none" stroke="{t["s1"]}" stroke-width="2.25" stroke-linejoin="round"/>')

    # capital flows: small markers on the fund line, labelled
    for d, a in flows.items():
        if d in f.index:
            x, y = X(d), Y(f[d])
            label = f"{'Subscription' if a > 0 else 'Redemption'} {'+' if a > 0 else '−'}€{abs(a) / 1e6:.1f}M"
            ly = y + 30 if a > 0 else y - 20
            out.append(f'<line x1="{x:.1f}" x2="{x:.1f}" y1="{y:.1f}" y2="{ly + (-12 if a > 0 else 6):.1f}" stroke="{t["ink2"]}" stroke-width="1"/>')
            out.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="4.5" fill="{t["surface"]}" stroke="{t["ink"]}" stroke-width="1.5"/>')
            out.append(f'<text x="{x:.1f}" y="{ly:.1f}" text-anchor="middle" fill="{t["ink"]}" font-size="{font - 1}" '
                       f'paint-order="stroke" stroke="{t["surface"]}" stroke-width="6" stroke-linejoin="round">{label}</text>')

    # direct end labels (legend lives in the card header)
    fe, be = f.iloc[-1], b.iloc[-1]
    yf, yb = Y(fe), Y(be)
    if abs(yf - yb) < 30:
        yf, yb = (yf - 15, yb + 15) if yf < yb else (yf + 15, yb - 15)
    xe = w - pad_r + 12
    out.append(f'<circle cx="{X(f.index[-1]):.1f}" cy="{Y(fe):.1f}" r="4.5" fill="{t["s1"]}" stroke="{t["surface"]}" stroke-width="2"/>')
    out.append(f'<text x="{xe}" y="{yf - 2:.1f}" fill="{t["ink"]}" font-weight="600" font-size="{font + 2}">{pct(fe)}</text>')
    out.append(f'<text x="{xe}" y="{yf + 15:.1f}" fill="{t["ink2"]}" font-size="{font - 1}">Fund</text>')
    out.append(f'<text x="{xe}" y="{yb - 2:.1f}" fill="{t["ink2"]}" font-weight="600" font-size="{font + 2}">{pct(be)}</text>')
    out.append(f'<text x="{xe}" y="{yb + 15:.1f}" fill="{t["muted"]}" font-size="{font - 1}">Benchmark</text>')
    out.append("</svg>")
    return "\n".join(out)


def monthly_bars(monthly: pd.DataFrame, t, w=560, h=250, font=12):
    pad_l, pad_r, pad_t, pad_b = 44, 8, 12, 30
    vals = monthly.values
    ticks, _ = _nice_ticks(min(vals.min(), 0) - 0.003, max(vals.max(), 0) + 0.003, 4)
    y_lo, y_hi = ticks[0], ticks[-1]
    iw, ih = w - pad_l - pad_r, h - pad_t - pad_b
    n = len(monthly)
    slot = iw / n
    bw = min(18, slot * 0.32)
    gap = 2

    def Y(v):
        return pad_t + (y_hi - v) / (y_hi - y_lo) * ih

    out = [f'<svg viewBox="0 0 {w} {h}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="Inter, sans-serif" font-size="{font}">']
    for v in ticks:
        y = Y(v)
        col = t["axis"] if abs(v) < 1e-12 else t["grid"]
        out.append(f'<line x1="{pad_l}" x2="{w - pad_r}" y1="{y:.1f}" y2="{y:.1f}" stroke="{col}"/>')
        lab = pct(v, 0)
        out.append(f'<text x="{pad_l - 8}" y="{y + 4:.1f}" text-anchor="end" fill="{t["muted"]}" style="font-variant-numeric:tabular-nums">{lab}</text>')
    y0 = Y(0)
    for i, (d, row) in enumerate(monthly.iterrows()):
        cx = pad_l + slot * (i + 0.5)
        for j, (col, color) in enumerate([("fund", t["s1"]), ("benchmark", t["bench"])]):
            x = cx - bw - gap / 2 if j == 0 else cx + gap / 2
            out.append(f'<path d="{_bar_path(x, y0, bw, Y(row[col]))}" fill="{color}"/>')
        out.append(f'<text x="{cx:.1f}" y="{h - 9}" text-anchor="middle" fill="{t["muted"]}">{d:%b}</text>')
    out.append("</svg>")
    return "\n".join(out)


def allocation_strip(alloc: pd.Series, t, w=560, h=18):
    """Part-to-whole in one bar, 2px surface gaps between segments."""
    cols = class_colors(t)
    out = [f'<svg viewBox="0 0 {w} {h}" width="100%" xmlns="http://www.w3.org/2000/svg">']
    x = 0.0
    for k in CLASS_ORDER:
        seg = alloc.get(k, 0) * w
        if seg <= 0:
            continue
        out.append(f'<rect x="{x:.1f}" y="0" width="{max(seg - 2, 1):.1f}" height="{h}" rx="3" fill="{cols[k]}"/>')
        x += seg
    out.append("</svg>")
    return "\n".join(out)


def contribution_bars(contrib: pd.Series, t, w=560, row=30, font=12.5, label_w=190):
    """Diverging horizontal bars in basis points of NAV: blue adds, red detracts."""
    c = contrib * 1e4
    lim = max(abs(c.min()), abs(c.max())) * 1.15
    h = row * len(c) + 8
    val_w = 58
    iw = w - label_w - val_w
    mid = label_w + iw / 2
    out = [f'<svg viewBox="0 0 {w} {h}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="Inter, sans-serif" font-size="{font}">']
    out.append(f'<line x1="{mid}" x2="{mid}" y1="0" y2="{h}" stroke="{t["axis"]}"/>')
    for i, (name, v) in enumerate(c.items()):
        y = 4 + i * row
        bh = row * 0.46
        yb = y + (row - bh) / 2
        length = v / lim * iw / 2
        color = t["s1"] if v >= 0 else t["neg"]
        xs, xe = (mid, mid + length) if v >= 0 else (mid + length, mid)
        r = min(3, abs(length) / 2)
        if v >= 0:
            d = f"M{xs},{yb} H{xe - r} Q{xe},{yb} {xe},{yb + r} V{yb + bh - r} Q{xe},{yb + bh} {xe - r},{yb + bh} H{xs} Z"
        else:
            d = f"M{xe},{yb} H{xs + r} Q{xs},{yb} {xs},{yb + r} V{yb + bh - r} Q{xs},{yb + bh} {xs + r},{yb + bh} H{xe} Z"
        out.append(f'<path d="{d}" fill="{color}"/>')
        out.append(f'<text x="0" y="{y + row / 2 + 4:.1f}" fill="{t["ink2"]}">{escape(str(name))}</text>')
        out.append(f'<text x="{w}" y="{y + row / 2 + 4:.1f}" text-anchor="end" fill="{t["ink"]}" '
                   f'style="font-variant-numeric:tabular-nums">{signed(v, 0)} bp</text>')
    out.append("</svg>")
    return "\n".join(out)
