"""Portfolio visuals: pipeline architecture, 'messy in / clean out', cover."""
import base64
import json
from html import escape
from pathlib import Path

import pandas as pd

from .charts import DARK, pct
from .dashboard import STATUS_ICON, base_css, eur, status_chip, status_color

RAW = Path(__file__).resolve().parents[1] / "data" / "raw"
MONO = "'DejaVu Sans Mono', monospace"


def _img(path: Path) -> str:
    return "data:image/png;base64," + base64.b64encode(path.read_bytes()).decode()


def architecture(r) -> str:
    t = DARK
    cs = r["check_summary"]
    cols = [
        ("1 · Sources", "Raw files, as received", [
            ("US broker", "CSV · USD · ISO dates"),
            ("Private bank", "Excel · EUR · “1 234,56” · dd/mm/yyyy"),
            ("Crypto exchange", "JSON API · USD · epoch ms"),
            ("Market data vendor", "Daily closes · EUR/USD fixing"),
            ("Internal ledger", "The fund's own books"),
        ]),
        ("2 · Ingestion", "One adapter per format", [
            ("Header detection", "Skips the bank's banner rows"),
            ("Locale parsing", "French numbers and dates"),
            ("Symbol mapping", "Exchange aliases → internal ids"),
            ("Common schema", "9 fields for every position"),
        ]),
        ("3 · Quality gate", f"{cs['total']} automated checks", [
            ("Schema & duplicates", "Required fields, repeated lines"),
            ("Price controls", "Freshness, ±0.5% vs vendor"),
            ("Reconciliation", "Custodian vs internal ledger"),
            ("Tie-out", "Recomputed values vs statements"),
        ]),
        ("4 · Consolidation", "Everything in EUR", [
            ("FX conversion", "Daily vendor fixing"),
            ("NAV rebuild", "Daily, 9 months of history"),
            ("Performance", "Time-weighted, net of flows"),
            ("Risk & attribution", "Vol, Sharpe, drawdown, bp"),
        ]),
        ("5 · Outputs", "Generated, not assembled", [
            ("Operations dashboard", "For the team, every run"),
            ("Investor PDF report", "4 pages, ready to send"),
            ("Audit trail", "Every check and correction logged"),
            ("Clean datasets", "Positions and NAV history (CSV)"),
        ]),
    ]
    col_html = ""
    for i, (h, sub, items) in enumerate(cols):
        accent = i in (2,)
        boxes = "".join(f'<div class="box"><div class="bt">{a}</div><div class="bs">{b}</div></div>' for a, b in items)
        col_html += f'<div class="col{" acc" if accent else ""}"><div class="ct">{h}</div><div class="cs">{sub}</div>{boxes}</div>'
        if i < len(cols) - 1:
            col_html += f'<div class="arrow"><svg width="28" height="28" viewBox="0 0 28 28"><path d="M4 14 H22 M16 8 L22 14 L16 20" stroke="{t["ink2"]}" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></div>'
    return f"""<!doctype html><html><head><meta charset="utf-8"><style>{base_css(t)}
body {{ width:1600px; height:1200px; padding:64px 64px; display:flex; flex-direction:column; }}
.big {{ font-size: 46px; font-weight: 700; letter-spacing: -.025em; line-height:1.1; margin: 14px 0 12px; }}
.lead {{ font-size: 19px; color:{t['ink2']}; max-width: 1100px; line-height:1.5; }}
.flow {{ display:flex; align-items:stretch; gap: 8px; margin-top: 48px; }}
.res {{ margin-top: 26px; display:flex; gap: 40px; align-items:baseline; padding: 20px 26px; border-radius:14px; background:{t['surface']}; border:1px solid {t['border']}; }}
.res .v {{ font-size: 26px; font-weight: 700; letter-spacing:-.01em; }}
.res .l {{ font-size: 14px; color:{t['ink2']}; }}
.col {{ flex:1; background:{t['surface']}; border:1px solid {t['border']}; border-radius:16px; padding:26px 18px 14px; }}
.col.acc {{ border: 1.5px solid {t['s1']}; box-shadow: 0 0 0 4px rgba(57,135,229,.12); }}
.ct {{ font-size: 21px; font-weight: 650; }}
.cs {{ font-size: 15px; color:{t['ink2']}; margin: 5px 0 22px; }}
.box {{ background:{t['page']}; border:1px solid {t['border']}; border-radius:10px; padding: 16px 15px; margin-bottom: 12px; }}
.bt {{ font-size: 16.5px; font-weight: 600; }}
.bs {{ font-size: 14px; color:{t['ink2']}; margin-top: 4px; line-height:1.4; }}
.arrow {{ display:flex; align-items:center; }}
.foot {{ margin-top:auto; display:flex; gap: 12px; flex-wrap: wrap; }}
.pill {{ font-size: 14px; padding: 8px 14px; border-radius: 999px; border:1px solid {t['border']}; color:{t['ink2']}; }}
.pill b {{ color:{t['ink']}; font-weight:600; }}
</style></head><body>
<div class="eyebrow">How it works</div>
<div class="big">From three messy custodian files<br>to an investor-ready report, in one run</div>
<div class="lead">Each custodian exports in its own format, currency and conventions. The pipeline normalises them, checks every number, consolidates in euros and produces the dashboard and the PDF, with a full audit trail.</div>
<div class="flow">{col_html}</div>
<div class="res"><span class="eyebrow">This run</span>
  <div><div class="v">3 files</div><div class="l">3 formats, 2 currencies</div></div>
  <div><div class="v">{r['n_positions']} positions</div><div class="l">consolidated in EUR</div></div>
  <div><div class="v">{cs['Auto-fixed']} fixed · {cs['Warning'] + cs['Break']} flagged</div><div class="l">out of {cs['total']} checks</div></div>
  <div><div class="v">{eur(r['history']['nav'].iloc[-1], 2)}</div><div class="l">net asset value, 30 Sep 2026</div></div>
</div>
<div class="foot">
  <span class="pill"><b>Python</b> · pandas</span><span class="pill"><b>Excel, CSV, JSON</b> adapters</span>
  <span class="pill"><b>HTML → PDF</b> via headless Chromium</span><span class="pill"><b>Charts</b> hand-built in SVG</span>
  <span class="pill">Data pipeline runs in <b>{r['runtime_s']:.2f} s</b></span><span class="pill"><b>Fictional</b> demo data</span>
</div>
</body></html>"""


def messy_to_clean(r) -> str:
    t = DARK
    broker = (RAW / "broker_positions_20260930.csv").read_text().splitlines()
    bank = pd.read_excel(RAW / "releve_banque_privee_sept2026.xlsx", header=None, dtype=str)
    api = json.loads((RAW / "exchange_balances_20260930.json").read_text())

    def hl(s, kind):
        c = {"fix": t["good"], "warn": t["warn"], "break": t["crit"]}[kind]
        return f'<span class="hl" style="border-color:{c};background:{c}22">{escape(s)}</span>'

    b_lines = [escape(broker[0])]
    for i, line in enumerate(broker[1:7], 1):
        e = escape(line)
        if i == 5:
            e = hl(line, "fix") + f' <span class="tag" style="color:{t["good"]}">↻ duplicate</span>'
        elif line.startswith("NVDA"):
            e = hl(line, "break") + f' <span class="tag" style="color:{t["crit"]}">✕ ledger says 4,250</span>'
        b_lines.append(e)
    hdr = bank.iloc[5].tolist()
    ai = bank[bank.iloc[:, 1] == "Air Liquide"].iloc[0].tolist()
    oat = bank[bank.iloc[:, 1].astype(str).str.startswith("OAT")].iloc[0].tolist()
    bank_lines = [escape(str(bank.iloc[0, 0])), "…",
                  escape(" | ".join(hdr[1:2] + hdr[3:6] + hdr[7:8])),
                  escape(" | ".join([oat[1], oat[3], oat[4], oat[5], oat[7]])),
                  hl(" | ".join([ai[1], ai[3], ai[4], ai[5], ai[7]]), "warn") + f' <span class="tag" style="color:{t["warn"]}">▲ stale price</span>']
    btc = api["balances"][0]
    api_lines = ['"server_time": ' + str(api["server_time"]) + ",",
                 '{ ' + hl(f'"asset": "{btc["asset"]}"', "fix") + f', "free": "{btc["free"]}" }} <span class="tag" style="color:{t["good"]}">↻ alias → BTC</span>',
                 '{ "asset": "ETH", "free": "170.5", "locked": "10.0" }',
                 '"tickers": { "XBTUSD": "' + api["tickers"]["XBTUSD"] + '", … }']

    pos = r["positions"].head(9)
    rows = "".join(
        f"<tr><td>{escape(x.name)}</td><td>{x.asset_class}</td><td>{x.currency}</td>"
        f"<td class='r'>{x.market_value_eur:,.0f}</td><td class='r'>{x.weight:.1%}</td></tr>" for x in pos.itertuples())
    nav = r["history"]["nav"].iloc[-1]
    checks = "".join(
        f'<div class="ck"><span style="color:{status_color(t, s)}">{STATUS_ICON[s]}</span>{escape(c)}</div>'
        for s, c in r["checks"][["status", "check"]].drop_duplicates("check").itertuples(index=False))

    def panel(title, sub, lines):
        return (f'<div class="raw"><div class="rt"><span>{title}</span><span class="sub">{sub}</span></div>'
                f'<pre>{chr(10).join(lines)}</pre></div>')

    return f"""<!doctype html><html><head><meta charset="utf-8"><style>{base_css(t)}
body {{ width:1600px; height:1200px; padding:118px 64px 0; }}
.big {{ font-size: 42px; font-weight: 700; letter-spacing: -.025em; line-height:1.1; margin: 12px 0 10px; }}
.lead {{ font-size: 18px; color:{t['ink2']}; max-width: 1150px; line-height:1.5; }}
.wrap {{ display:grid; grid-template-columns: 1fr 60px 1fr; gap: 0; margin-top: 44px; align-items:stretch; }}
.side {{ display:flex; flex-direction:column; gap: 18px; }}
.lab {{ font-size: 14px; font-weight: 650; letter-spacing:.06em; text-transform:uppercase; color:{t['muted']}; margin-bottom: 2px; }}
.raw {{ background:{t['surface']}; border:1px solid {t['border']}; border-radius:12px; padding: 18px 18px; }}
.rt {{ display:flex; justify-content:space-between; font-size: 15px; font-weight:600; margin-bottom: 10px; }}
pre {{ font-family: {MONO}; font-size: 13.2px; line-height: 2.0; color:{t['ink2']}; white-space: pre; overflow:hidden; }}
.hl {{ border:1px solid; border-radius:4px; padding: 1px 3px; color:{t['ink']}; }}
.tag {{ font-family: Inter, sans-serif; font-weight:600; font-size: 13px; }}
.mid {{ display:flex; align-items:center; justify-content:center; }}
.card table {{ width:100%; border-collapse: collapse; font-size: 14px; font-variant-numeric: tabular-nums; }}
.card th {{ text-align:left; color:{t['muted']}; font-size: 11.5px; text-transform: uppercase; letter-spacing: .06em; font-weight:600; padding: 0 6px 8px; border-bottom: 1px solid {t['axis']}; }}
.card td {{ padding: 11px 6px; border-bottom: 1px solid {t['grid']}; }}
.r {{ text-align:right; }}
.navrow {{ display:flex; justify-content:space-between; align-items:baseline; margin-top: 12px; }}
.navv {{ font-size: 28px; font-weight: 700; letter-spacing:-.02em; }}
.cks {{ display:grid; grid-template-columns: 1fr 1fr; gap: 12px 16px; font-size: 14.5px; color:{t['ink2']}; }}
.ck span {{ display:inline-block; width: 18px; font-weight:700; }}
</style></head><body>
<div class="eyebrow">Data quality</div>
<div class="big">Every number is checked before it reaches an investor</div>
<div class="lead">Real excerpts from the three raw files on the left. Problems are caught, corrected or escalated automatically, and every decision is written to an audit log.</div>
<div class="wrap">
  <div class="side">
    <div class="lab">Raw input</div>
    {panel("US broker", "broker_positions.csv", b_lines)}
    {panel("Private bank", "releve_banque_privee.xlsx", bank_lines)}
    {panel("Crypto exchange", "exchange_balances.json", api_lines)}
  </div>
  <div class="mid"><svg width="36" height="36" viewBox="0 0 28 28"><path d="M4 14 H22 M16 8 L22 14 L16 20" stroke="{t['ink']}" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
  <div class="side">
    <div class="lab">Clean, consolidated output</div>
    <div class="card"><table><thead><tr><th>Position</th><th>Class</th><th>Ccy</th><th class='r'>Value (EUR)</th><th class='r'>Weight</th></tr></thead><tbody>{rows}</tbody></table>
      <div class="navrow"><span class="sub">… {len(r['positions'])} positions · net asset value</span><span class="navv">{eur(nav, 2)}</span></div></div>
    <div class="card"><div class="rt" style="display:flex;justify-content:space-between;font-weight:600;margin-bottom:12px"><span>Audit log · {r['check_summary']['total']} checks</span>
      <span>{status_chip(t, 'Auto-fixed')} {status_chip(t, 'Warning')} {status_chip(t, 'Break')}</span></div>
      <div class="cks">{checks}</div></div>
  </div>
</div>
</body></html>"""


def cover(r, dashboard_png: Path, report_png: Path) -> str:
    t = DARK
    cs = r["check_summary"]
    return f"""<!doctype html><html><head><meta charset="utf-8"><style>{base_css(t)}
body {{ width:1600px; height:1200px; overflow:hidden; position:relative;
  background: radial-gradient(1100px 700px at 85% 20%, rgba(57,135,229,.20), transparent 60%), {t['page']}; }}
.txt {{ position:absolute; left:80px; top:96px; width: 700px; z-index:3; }}
.big {{ font-size: 70px; font-weight: 750; letter-spacing: -.035em; line-height: 1.02; margin: 22px 0 26px; }}
.big .b {{ color:{t['s1']}; }}
.lead {{ font-size: 21px; color:{t['ink2']}; line-height: 1.5; max-width: 600px; }}
.stats {{ position:absolute; left:80px; top: 590px; display:flex; flex-direction:column; gap: 30px; z-index:3; }}
.stack {{ position:absolute; left:80px; bottom: 80px; font-size: 15px; color:{t['muted']}; z-index:3; }}
.st {{ display:flex; align-items:baseline; gap:16px; border-top:1px solid {t['border']}; padding-top: 22px; width: 560px; }}
.st .v {{ min-width: 190px; white-space: nowrap; font-size: 44px; font-weight: 700; letter-spacing:-.02em; }}
.st .l {{ font-size: 18px; color:{t['ink2']}; }}
.shot {{ position:absolute; border-radius: 16px; box-shadow: 0 40px 100px rgba(0,0,0,.65), 0 0 0 1px rgba(255,255,255,.12); }}
.dash {{ width: 1150px; left: 760px; top: 190px; transform: perspective(2200px) rotateY(-16deg) rotateX(4deg); transform-origin: left center; }}
.pdf {{ width: 380px; left: 690px; top: 560px; border-radius: 6px; transform: rotate(-4deg); box-shadow: 0 40px 90px rgba(0,0,0,.7); z-index: 2; }}
.badge {{ position:absolute; left: 700px; top: 520px; z-index: 4; transform: rotate(-4deg); }}
.chips {{ display:flex; gap:10px; flex-wrap:wrap; }}
.chip {{ font-size: 14px; padding: 6px 12px; background: rgba(255,255,255,.04); }}
</style></head><body>
<div class="txt">
  <div class="chips"><span class="chip">Python automation</span><span class="chip">Financial reporting</span><span class="chip">Data quality</span></div>
  <div class="big">3 custodians.<br>3 formats.<br><span class="b">1 investor report.</span></div>
  <div class="lead">A pipeline that consolidates a multi-custodian portfolio in euros, checks every number and generates the dashboard and the investor PDF automatically.</div>
</div>
<img class="shot dash" src="{_img(dashboard_png)}">
<img class="shot pdf" src="{_img(report_png)}">
<div class="stats">
  <div class="st"><div class="v">{cs['total']}</div><div class="l">automated data checks</div></div>
  <div class="st"><div class="v">{r['runtime_s']:.1f} s</div><div class="l">to process 3 sources, 9 months of data</div></div>
  <div class="st"><div class="v">4 pages</div><div class="l">investor PDF, generated</div></div>
</div>
<div class="stack">Python · pandas · headless Chromium · fictional demo data</div>
</body></html>"""
