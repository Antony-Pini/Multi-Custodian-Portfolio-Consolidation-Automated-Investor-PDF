"""Headless Chromium: HTML -> PNG screenshots and PDF."""
from pathlib import Path
from playwright.sync_api import sync_playwright


def screenshot(html: str, out: Path, w=1600, h=1200, scale=2):
    tmp = out.resolve().with_suffix(".html")
    tmp.write_text(html, encoding="utf-8")
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": w, "height": h}, device_scale_factor=scale)
        pg.goto(tmp.as_uri())
        pg.wait_for_timeout(300)
        pg.screenshot(path=str(out), full_page=False)
        b.close()
    return out


def pdf(html: str, out: Path):
    tmp = out.resolve().with_suffix(".html")
    tmp.write_text(html, encoding="utf-8")
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page()
        pg.goto(tmp.as_uri())
        pg.wait_for_timeout(300)
        pg.pdf(path=str(out), format="A4", print_background=True, prefer_css_page_size=True)
        b.close()
    return out
